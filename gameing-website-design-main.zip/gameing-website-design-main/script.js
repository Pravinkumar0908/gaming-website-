jQuery(document).ready(function($){
	var $slickElement = $('.slideshow');

	$slickElement.slick({
	  autoplay: true,
	  dots: false,
	});

});